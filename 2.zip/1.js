
// simple hello message
document.write('Hello Java script');
document.writeln('Welcome to javaScript<br>');
document.writeln('This is JavaScript Class<br>');

/* write a a para with
red color
on html 
document 
*/
document.writeln('<p style="color:red;">Welcome to javaScript</p>');
document.writeln("<br>");


